// src/App.test.js
import React from 'react';
import { render, screen } from '@testing-library/react';
import { BrowserRouter as Router } from 'react-router-dom';
import AppWrapper from './App';

// Mock the AuthContext to simulate an authenticated user
jest.mock('./src/contexts/AuthContext.js', () => ({
  AuthProvider: ({ children }) => <div>{children}</div>,
  useAuth: () => ({ isAuthenticated: true }),
}));

// Mock the ThemeContext
jest.mock('./contexts/ThemeContext', () => ({
  ThemeProvider: ({ children }) => <div>{children}</div>,
}));

test('renders without crashing', () => {
  render(
    <Router>
      <AppWrapper />
    </Router>
  );

  // Check if the "Logout" button is present (indicating the user is on the sale orders page)
  const logoutButton = screen.getByText(/logout/i);
  expect(logoutButton).toBeInTheDocument();
});
