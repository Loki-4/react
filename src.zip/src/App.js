// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import LoginPage from './pages/LoginPage';
import SaleOrderPage from './pages/SaleOrderPage';
import RequireAuth from './components/auth/RequireAuth';

const App = () => (
  <Router>
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route
        path="/sale-orders"
        element={
          <RequireAuth>
            <SaleOrderPage />
          </RequireAuth>
        }
      />
      <Route path="/" element={<Navigate to="/sale-orders" />} />
    </Routes>
  </Router>
);

const AppWrapper = () => (
  <ThemeProvider>
    <AuthProvider>
      <App />
    </AuthProvider>
  </ThemeProvider>
);

export default AppWrapper;
