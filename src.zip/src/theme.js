// src/theme.js
import { extendTheme } from '@chakra-ui/react';

const theme = extendTheme({
  // Define your theme configuration here
});

export default theme;
