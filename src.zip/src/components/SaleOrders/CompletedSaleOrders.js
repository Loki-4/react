// src/components/SaleOrders/CompletedSaleOrders.js
import React from 'react';
import { Table, Thead, Tbody, Tr, Th, Td, IconButton } from '@chakra-ui/react';
import { useDisclosure } from '@chakra-ui/hooks';
import { EditIcon } from '@chakra-ui/icons';
import SaleOrderForm from './SaleOrderForm';

const CompletedSaleOrders = () => {
  const { isOpen, onOpen, onClose } = useDisclosure();

  return (
    <Table variant="simple">
      <Thead>
        <Tr>
          <Th>Invoice No</Th>
          <Th>Customer</Th>
          <Th>Date</Th>
          <Th>Actions</Th>
        </Tr>
      </Thead>
      <Tbody>
        {/* Mock Data */}
        <Tr>
          <Td>Invoice - 1212121</Td>
          <Td>Ram</Td>
          <Td>7/5/2024</Td>
          <Td>
            <IconButton icon={<EditIcon />} onClick={onOpen} />
          </Td>
        </Tr>
      </Tbody>
      <SaleOrderForm isOpen={isOpen} onClose={onClose} readOnly />
    </Table>
  );
};

export default CompletedSaleOrders;
