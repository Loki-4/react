// src/components/SaleOrders/ActiveSaleOrders.js
import React from 'react';
import { Box, Button, Table, Thead, Tbody, Tr, Th, Td, IconButton } from '@chakra-ui/react';
import { useDisclosure } from '@chakra-ui/hooks';
import { EditIcon } from '@chakra-ui/icons';
import SaleOrderForm from './SaleOrderForm';

const ActiveSaleOrders = () => {
  const { isOpen, onOpen, onClose } = useDisclosure();

  return (
    <Box>
      <Button onClick={onOpen} mb={4}>+ Sale Order</Button>
      <Table variant="simple">
        <Thead>
          <Tr>
            <Th>Invoice No</Th>
            <Th>Customer</Th>
            <Th>Date</Th>
            <Th>Actions</Th>
          </Tr>
        </Thead>
        <Tbody>
          {/* Mock Data */}
          <Tr>
            <Td>Invoice - 1212121</Td>
            <Td>Ram</Td>
            <Td>7/5/2024</Td>
            <Td>
              <IconButton icon={<EditIcon />} onClick={onOpen} />
            </Td>
          </Tr>
        </Tbody>
      </Table>
      <SaleOrderForm isOpen={isOpen} onClose={onClose} />
    </Box>
  );
};

export default ActiveSaleOrders;

