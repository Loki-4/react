// src/components/SaleOrders/SaleOrderTable.js
import React from 'react';
import { Table, Thead, Tbody, Tr, Th, Td, IconButton } from '@chakra-ui/react';
import { EditIcon } from '@chakra-ui/icons';
import { useDisclosure } from '@chakra-ui/hooks';
import SaleOrderForm from './SaleOrderForm';

const SaleOrderTable = ({ orders, readOnly = false }) => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [selectedOrder, setSelectedOrder] = React.useState(null);

  const handleEditClick = (order) => {
    setSelectedOrder(order);
    onOpen();
  };

  return (
    <>
      <Table variant="simple">
        <Thead>
          <Tr>
            <Th>Invoice No</Th>
            <Th>Customer</Th>
            <Th>Date</Th>
            <Th>Actions</Th>
          </Tr>
        </Thead>
        <Tbody>
          {orders.map((order) => (
            <Tr key={order.id}>
              <Td>{order.invoice_no}</Td>
              <Td>{order.customer_id}</Td>
              <Td>{order.invoice_date}</Td>
              <Td>
                <IconButton
                  icon={<EditIcon />}
                  onClick={() => handleEditClick(order)}
                />
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>
      <SaleOrderForm
        isOpen={isOpen}
        onClose={onClose}
        order={selectedOrder}
        readOnly={readOnly}
      />
    </>
  );
};

export default SaleOrderTable;
