// src/components/SaleOrders/SaleOrderForm.js
import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import './customDatePicker.css'; // Ensure the path is correct relative to your file structure

import {
  Select,
} from '@chakra-ui/react';
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Button,
  FormControl,
  FormLabel,
  Input,
} from '@chakra-ui/react';

import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const SaleOrderForm = ({ isOpen, onClose, order, readOnly = false }) => {
  const { handleSubmit, register, control, setValue } = useForm({
    defaultValues: {
      invoice_no: order?.invoice_no || '',
      customer_id: order?.customer_id || '',
      invoice_date: order?.invoice_date || '',
      items: order?.items || [],
    },
  });

  React.useEffect(() => {
    if (order) {
      setValue('invoice_no', order.invoice_no);
      setValue('customer_id', order.customer_id);
      setValue('invoice_date', order.invoice_date);
      setValue('items', order.items);
    }
  }, [order, setValue]);

  const onSubmit = (data) => {
    console.log(data);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>{readOnly ? 'View Sale Order' : 'Create/Edit Sale Order'}</ModalHeader>
        <ModalCloseButton />
        <ModalBody>
          <form onSubmit={handleSubmit(onSubmit)}>
            <FormControl>
              <FormLabel>Invoice No</FormLabel>
              <Input {...register('invoice_no')} isReadOnly={readOnly} />
            </FormControl>
            <FormControl mt={4}>
              <FormLabel>Customer</FormLabel>
              <Select {...register('customer_id')} isReadOnly={readOnly}>
                <option value="11908">Ram</option>
                {/* Add more customers */}
              </Select>
            </FormControl>
            <FormControl mt={4}>
              <FormLabel>Date</FormLabel>
              <Controller
                control={control}
                name="invoice_date"
                render={({ field }) => (
                  <DatePicker
                    selected={field.value}
                    onChange={field.onChange}
                    disabled={readOnly}
                  />
                )}
              />
            </FormControl>
            <FormControl mt={4}>
              <FormLabel>Items</FormLabel>
              {/* Add item selection (MultiSelect) */}
            </FormControl>
          </form>
        </ModalBody>
        <ModalFooter>
          {!readOnly && (
            <Button type="submit" colorScheme="blue" mr={3}>
              Save
            </Button>
          )}
          <Button variant="ghost" onClick={onClose}>
            Close
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default SaleOrderForm;
