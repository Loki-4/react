// src/hooks/useSaleOrders.js
import { useQuery, useMutation, useQueryClient } from 'react-query';

const fetchSaleOrders = async () => {
  // Mock API call
  return [
    {
      id: 1,
      invoice_no: 'Invoice - 1212121',
      customer_id: 11908,
      invoice_date: '7/5/2024',
      items: [{ sku_id: 220, price: 12, quantity: 12 }],
      paid: false,
    },
  ];
};

const createSaleOrder = async (newSaleOrder) => {
  // Mock API call
  return newSaleOrder;
};

const useSaleOrders = () => {
  return useQuery('saleOrders', fetchSaleOrders);
};

const useCreateSaleOrder = () => {
  const queryClient = useQueryClient();
  return useMutation(createSaleOrder, {
    onSuccess: () => {
      queryClient.invalidateQueries('saleOrders');
    },
  });
};

export { useSaleOrders, useCreateSaleOrder };
