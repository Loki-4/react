// src/pages/SaleOrderPage.js
import React from 'react';
import { Tabs, TabList, TabPanels, Tab, TabPanel, Box, Button, Flex } from '@chakra-ui/react';
import { useTheme } from '../contexts/ThemeContext';
import ActiveSaleOrders from '../components/SaleOrders/ActiveSaleOrders';
import CompletedSaleOrders from '../components/SaleOrders/CompletedSaleOrders';

const SaleOrderPage = () => {
  const { darkMode, toggleDarkMode } = useTheme();

  return (
    <Box p={4}>
      <Flex justify="space-between" align="center" mb={4}>
        <Button onClick={toggleDarkMode}>{darkMode ? 'Light Mode' : 'Dark Mode'}</Button>
      </Flex>
      <Tabs isFitted variant="enclosed">
        <TabList>
          <Tab>Active Sale Orders</Tab>
          <Tab>Completed Sale Orders</Tab>
        </TabList>
        <TabPanels>
          <TabPanel>
            <ActiveSaleOrders />
          </TabPanel>
          <TabPanel>
            <CompletedSaleOrders />
          </TabPanel>
        </TabPanels>
      </Tabs>
    </Box>
  );
};

export default SaleOrderPage;
